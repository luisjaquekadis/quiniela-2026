// Base de datos y API para la Copa Mundial de la FIFA 2026

async function fetchWorldCupData() {
  try {
    const response = await fetch(`/api/2026.json?t=${Date.now()}`, { cache: 'no-store' });
    const data = await response.json();
    return data.matches || [];
  } catch (error) {
    console.error("Error fetching World Cup data:", error);
    return [];
  }
}

const STAGES = [
  "Todos",
  "Fase de Grupos",
  "Dieciseisavos de Final",
  "Octavos de Final",
  "Cuartos de Final",
  "Semifinal",
  "Tercer Lugar",
  "Gran Final"
];

// --- INTEGRACIÓN ESPN PARA MARCADORES EN VIVO ---
const ESPNDictionary = {
  "Algeria": "Argelia", "Argentina": "Argentina", "Australia": "Australia", "Austria": "Austria",
  "Belgium": "Bélgica", "Bosnia-Herzegovina": "Bosnia y Herzegovina", "Brazil": "Brasil", "Canada": "Canadá",
  "Cape Verde": "Cabo Verde", "Colombia": "Colombia", "Congo DR": "RD Congo", "Croatia": "Croacia",
  "Curaçao": "Curazao", "Czechia": "República Checa", "Ecuador": "Ecuador", "Egypt": "Egipto",
  "England": "Inglaterra", "France": "Francia", "Germany": "Alemania", "Ghana": "Ghana",
  "Haiti": "Haití", "Iran": "Irán", "Iraq": "Irak", "Ivory Coast": "Costa de Marfil",
  "Japan": "Japón", "Jordan": "Jordania", "Mexico": "México", "Morocco": "Marruecos",
  "Netherlands": "Países Bajos", "New Zealand": "Nueva Zelanda", "Norway": "Noruega", "Panama": "Panamá",
  "Paraguay": "Paraguay", "Portugal": "Portugal", "Qatar": "Qatar", "Saudi Arabia": "Arabia Saudita",
  "Scotland": "Escocia", "Senegal": "Senegal", "South Africa": "Sudáfrica", "South Korea": "Corea del Sur",
  "Spain": "España", "Sweden": "Suecia", "Switzerland": "Suiza", "Tunisia": "Túnez",
  "Türkiye": "Turquía", "United States": "EE.UU.", "Uruguay": "Uruguay", "Uzbekistan": "Uzbekistán"
};

async function syncLiveScoresFromESPN() {
  try {
    const response = await fetch("https://site.api.espn.com/apis/site/v2/sports/soccer/fifa.world/scoreboard?dates=20260611-20260719");
    const data = await response.json();
    if (!data.events) return;

    let changesMade = false;
    let newExactMatches = 0;

    data.events.forEach(event => {
      // Importan los partidos terminados ("post") y en vivo ("in")
      if (event.status && event.status.type && (event.status.type.state === "post" || event.status.type.state === "in")) {
        const comp = event.competitions[0];
        if (!comp || !comp.competitors) return;

        const homeComp = comp.competitors.find(c => c.homeAway === "home");
        const awayComp = comp.competitors.find(c => c.homeAway === "away");
        
        if (!homeComp || !awayComp) return;

        const espnHome = homeComp.team.displayName;
        const espnAway = awayComp.team.displayName;
        const scoreHome = parseInt(homeComp.score);
        const scoreAway = parseInt(awayComp.score);

        const localHome = ESPNDictionary[espnHome] || espnHome;
        const localAway = ESPNDictionary[espnAway] || espnAway;

        // Buscar el ID del partido local (iterando los matches cargados)
        const localMatches = JSON.parse(localStorage.getItem("quiniela_matches_v10")) || [];
        const match = localMatches.find(m => m.homeTeam === localHome && m.awayTeam === localAway);

        if (match) {
          // Revisar si ya lo teníamos registrado
          if (match.realHomeScore !== scoreHome || match.realAwayScore !== scoreAway) {
            // Guardar usando qStorage global de profiles.js
            if (typeof qStorage !== 'undefined') {
              
              // Revisar si esto genera un confeti para el usuario activo
              const activeId = qStorage.getActiveProfileId();
              if (activeId) {
                const activePreds = qStorage.getPredictions()[activeId] || {};
                const myPred = activePreds[match.id];
                if (myPred && myPred.home === scoreHome && myPred.away === scoreAway) {
                   newExactMatches++;
                }
              }

              qStorage.saveRealScore(match.id, scoreHome, scoreAway);
              changesMade = true;
            }
          }
        }
      }
    });

    if (changesMade && typeof app !== 'undefined' && app.refreshUI) {
      app.refreshUI();
      if (newExactMatches > 0 && typeof app.triggerConfetti === 'function') {
        app.triggerConfetti();
      }
    }

    // Indicador visual de Live
    if (typeof document !== 'undefined') {
      const header = document.querySelector(".app-header");
      if (header && !document.getElementById("espn-sync-indicator")) {
        const syncInd = document.createElement("div");
        syncInd.id = "espn-sync-indicator";
        syncInd.style = "position: absolute; top: 6px; right: 10px; font-size: 9px; color: #10B981; font-weight: 600; display: flex; align-items: center; gap: 4px; z-index: 100;";
        syncInd.innerHTML = `<span style="width: 6px; height: 6px; background: #10B981; border-radius: 50%; animation: pulse 2s infinite;"></span> ESPN Live`;
        header.style.position = "relative";
        header.appendChild(syncInd);
      }
    }
  } catch (error) {
    console.error("Error sincronizando resultados desde ESPN:", error);
  }
}
